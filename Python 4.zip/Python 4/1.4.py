number =5
if number >=0:
    if number ==0:
        print("zero")
    else:
        print("positive")
else:
    print("negative")