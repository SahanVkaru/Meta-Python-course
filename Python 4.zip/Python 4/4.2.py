def greet():
    print("Hello World")

greet()