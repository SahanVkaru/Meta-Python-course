def find_squre(num):
    return num*num

result = find_squre(5)
print(result)