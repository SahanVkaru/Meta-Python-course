while True:
    print("This will run forever")
    break