
def print_squares():
    l = list()
    for i in range(1, 31):
        l.append(i**2)
    print(l)

print_squares()
