
for i in range(10):
    print(str(i) * i)
