
def reverse_string(s):
    return s[::-1]

s = "1234abcd"
print(reverse_string(s))
