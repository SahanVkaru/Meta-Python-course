number =-5
if number >0:
    print("number is positive")
else:
    print("number is negative")


    