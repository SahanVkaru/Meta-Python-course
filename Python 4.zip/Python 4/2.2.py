digit =[0,1,5]
for i in digit:
    print(i)
else:
    print("loop finished")