for i in range(5):
    print(i)


language = ["python","java","c++","javascript"]
for i in language:
    print(i)