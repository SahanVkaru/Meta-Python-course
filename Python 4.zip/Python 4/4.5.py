def greet(name,message="hi"):
    print(message,name)

    print(greet("Alice"))
    print(greet("Bob","Good morning"))