n=10
if n>10:
    pass
print("code continues")
