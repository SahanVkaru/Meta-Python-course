def add_numbers(a,b):
    print(num1+num2)

add_numbers(5,10)