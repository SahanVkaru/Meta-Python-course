# 1.3 if else condition

number =0
if number >0:
    print ("positive")
elif number ==0:
    print("zero")
else:
    print("Negative")